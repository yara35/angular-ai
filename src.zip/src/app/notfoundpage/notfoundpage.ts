import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-notfoundpage',
  imports: [RouterLink],
  templateUrl: './notfoundpage.html',
  styleUrl: './notfoundpage.css'
})
export class Notfoundpage {

}
