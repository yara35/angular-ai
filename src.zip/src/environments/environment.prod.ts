export const environment = {
  huggingfaceToken: '', 
  production: true
};
