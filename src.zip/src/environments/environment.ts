export const environment = {
  huggingfaceToken: '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'
};
